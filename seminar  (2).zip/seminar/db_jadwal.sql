-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 18, 2019 at 06:15 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_jadwal`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` varchar(32) NOT NULL,
  `nama` varchar(34) NOT NULL,
  `email` varchar(43) NOT NULL,
  `password` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `nama`, `email`, `password`) VALUES
('', '', 'ilham@gmail.com', 'ilhamar1');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `comment_id` int(50) NOT NULL,
  `post_id` int(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `content` text,
  `date_posted` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`comment_id`, `post_id`, `nama`, `content`, `date_posted`) VALUES
(2, 1, 'muammar', 'hayyy jugaaa', '1550466106'),
(3, 2, 'husein', 'berikkk luuu', '1550466204');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `eventname` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `eventdate` date DEFAULT NULL,
  `tempat` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `eventname`, `description`, `eventdate`, `tempat`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'Seminar IOT', 'acara besar', '2018-10-22', 'Jakarta', 1, '2018-12-14 00:00:00.000000', '2018-11-23 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `materis`
--

CREATE TABLE `materis` (
  `id` int(11) NOT NULL,
  `materi` varchar(255) DEFAULT NULL,
  `file` text,
  `start_time` time(6) DEFAULT NULL,
  `end_time` time(6) DEFAULT NULL,
  `event_id` varchar(11) DEFAULT NULL,
  `speaker_id` int(11) DEFAULT NULL,
  `date` varchar(42) DEFAULT NULL,
  `tempat` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp(6) NULL DEFAULT NULL,
  `updated_at` timestamp(6) NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `materis`
--

INSERT INTO `materis` (`id`, `materi`, `file`, `start_time`, `end_time`, `event_id`, `speaker_id`, `date`, `tempat`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'jaringan', 'https://drive.google.com/open?id=1Rr1JkwizwBRghSaHispGSlKYpLkT_EZ4', '07:48:00.000000', '08:48:44.000000', '1', 1, '2018-10-25', 'Ball Room', 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(2, 'data base', 'https://drive.google.com/file/d/1wDVJfnCnSeFj0rsVHUoZ5-0DJqI0J5vY/view?usp=sharing', '01:30:00.000000', '12:30:00.000000', '1', 2, '10/11/2018', 'smal room', NULL, NULL, NULL),
(3, 'big data', 'https://drive.google.com/file/d/1wDVJfnCnSeFj0rsVHUoZ5-0DJqI0J5vY/view?usp=sharing', '09:58:26.000000', '10:58:47.000000', '1', 3, '2018-10-23', 'Small Room', 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `post_id` int(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `content` text,
  `date_posted` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`post_id`, `nama`, `content`, `date_posted`) VALUES
(1, 'iqbal', 'hayyyyyy', '1437390045'),
(2, 'ilham', 'apa luuuu', '1550464684');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `question` varchar(255) DEFAULT NULL,
  `materi_id` int(11) DEFAULT NULL,
  `penanya` varchar(255) DEFAULT NULL,
  `instansi` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question`, `materi_id`, `penanya`, `instansi`, `created_at`, `updated_at`) VALUES
(1, 'Apa tujuan acara ini?', 1, 'Penanya 1', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'Bagaimana cara kita?', 1, 'Penanya 2', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `rundown`
--

CREATE TABLE `rundown` (
  `id_rundown` int(11) NOT NULL,
  `id_materi` int(11) NOT NULL,
  `waktu_mulai` time NOT NULL,
  `waktu_akhir` time NOT NULL,
  `keterangan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rundown`
--

INSERT INTO `rundown` (`id_rundown`, `id_materi`, `waktu_mulai`, `waktu_akhir`, `keterangan`) VALUES
(1, 1, '07:20:00', '08:00:00', 'registration'),
(2, 1, '08:00:00', '09:00:00', 'materi'),
(3, 1, '09:00:00', '11:00:00', 'tanya jawab');

-- --------------------------------------------------------

--
-- Table structure for table `speakers`
--

CREATE TABLE `speakers` (
  `id` int(11) NOT NULL,
  `speakername` varchar(255) DEFAULT NULL,
  `instansi` varchar(255) DEFAULT NULL,
  `jmlhlike` int(11) NOT NULL,
  `foto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `speakers`
--

INSERT INTO `speakers` (`id`, `speakername`, `instansi`, `jmlhlike`, `foto`) VALUES
(1, 'Speaker One', 'Kemenkes', 0, NULL),
(2, 'Speaker Two', 'Puskesmas', 0, NULL),
(3, 'Speaker Three', 'Dinkes', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ussers`
--

CREATE TABLE `ussers` (
  `id_ussers` varchar(14) NOT NULL,
  `name` varchar(17) NOT NULL,
  `email` varchar(54) NOT NULL,
  `phone_number` text NOT NULL,
  `date` text NOT NULL,
  `jenis_kelamin` enum('male','female') NOT NULL,
  `street_addreess` varchar(45) NOT NULL,
  `city` varchar(89) NOT NULL,
  `password` varchar(43) NOT NULL,
  `select_contry` varchar(44) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ussers`
--

INSERT INTO `ussers` (`id_ussers`, `name`, `email`, `phone_number`, `date`, `jenis_kelamin`, `street_addreess`, `city`, `password`, `select_contry`) VALUES
('15108071', 'tatang', 'tatang21@gmail.com', '08956412', '01/23/2019', '', 'jalan raya hankam', 'jakarta', 'tatang21', 'indonesia'),
('15108077', 'admin24', 'admin24@gmail.com', '', '2019-01-25', 'female', 'jalan raya hankam rt03 rw 03 no 85', 'bekasi', 'admin24', 'indonesia'),
('1518077', 'admin97', 'admin97@gmail.com', '901284329', '05/24/2018', '', 'jalan raya kenangan blok c 220', 'tanggerang', 'admin97', 'indonesia'),
('31232', 'admin25', 'admin25@gmail.com', '902482374', '01/18/2019', '', 'jalan raya hankam', 'bekasi', 'admin25', 'indonesia'),
('s', 's', 's@gmail.com', 's', '0000-00-00', '', 's', 's', 's', 's'),
('x', 'x', 'x@gmail.com', 'x', '01/11/2019', '', 'xxxxxx', 'x', 'x', 'x');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `materis`
--
ALTER TABLE `materis`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `rundown`
--
ALTER TABLE `rundown`
  ADD PRIMARY KEY (`id_rundown`);

--
-- Indexes for table `speakers`
--
ALTER TABLE `speakers`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `ussers`
--
ALTER TABLE `ussers`
  ADD PRIMARY KEY (`id_ussers`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `comment_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `materis`
--
ALTER TABLE `materis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `post_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `rundown`
--
ALTER TABLE `rundown`
  MODIFY `id_rundown` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
