<?php
// Create database connection using config file
include_once("config.php");
 
// Fetch all users data from database

$result1= mysqli_query($mysqli,"SELECT materis.materi,materis.file,materis.start_time,materis.end_time,materis.date, materis.tempat,speakers.speakername,speakers.instansi from speakers RIGHT OUTER JOIN materis on speakers.id=materis.speaker_id;");

$result3= mysqli_query($mysqli,"SELECT d.id_materi, a.materi,a.date, a.file,a.start_time, a.end_time, a.tempat , b.eventname, b.tempat, c.speakername, c.instansi, d.waktu_mulai, d.waktu_akhir, d.keterangan FROM materis a INNER JOIN speakers c on c.id = a.speaker_id INNER JOIN events b on b.id = a.event_id INNER JOIN rundown d on d.id_materi = a.id  ");

$result2=mysqli_query($mysqli,"SELECT dayname(materis.date) as day from speakers RIGHT OUTER JOIN materis on speakers.id=materis.speaker_id GROUP by materis.date;");



?>

<!DOCTYPE html>
<html>
<head>
<title>pusdatin-kemenkes | Home :: pusdatin</title>
<link href="css/pignose.layerslider.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/stylebutton.css" rel="stylesheet" type="text/css" media="all" />
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/php; charset=utf-8" />
<meta name="keywords" content="pusdatin-kemenkes Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<!--fonts-->
<link href='//fonts.googleapis.com/css?family=Poiret+One' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//fonts-->	
<!-- js -->
<script type="text/javascript" src="js/jquery.min.js"></script>
<!-- js -->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/bootstrap.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<link rel="stylesheet" href="css/font-awesome.min.css" />
        <link rel="stylesheet" type="text/css" href="css/custom.css" />
		<script type="text/javascript" src="js/modernizr.custom.79639.js"></script>		
		<!-- js for news -->
		<script src="js/jquery.easing.min.js"></script>
		<script type="text/javascript" src="js/pignose.layerslider.js"></script>
		<script type="text/javascript">
			//<![CDATA[
				$(window).load(function() {
					$('#visual').pignoseLayerSlider({
						play    : '.btn-play',
						pause   : '.btn-pause',
						next    : '.btn-next',
						prev    : '.btn-prev'
					});
				});
			//]]>
			</script>
		<!-- /js for news -->
		
		<!-- for smooth scrolling -->
		<script type="text/javascript" src="js/move-top.js"></script>
		<script type="text/javascript" src="js/easing.js"></script>
		<script type="text/javascript">
		jQuery(document).ready(function($) {
			$(".scroll").click(function(event){		
				event.preventDefault();
				$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
			});
		});
		</script>
		<!-- //for smooth scrolling -->
</head>
<body>
	<!-- header -->
	<div class="top-strip">
		<div class="container-fluid">
			<div class="social-icons">
				<a class="facebook" href="#"><i class="fa fa-facebook"></i></a>
				<a class="twitter" href="#"><i class="fa fa-twitter"></i></a>
				<a class="pinterest" href="#"><i class="fa fa-pinterest-p"></i></a>
				<a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a>
				<a class="tumblr" href="#"><i class="fa fa-tumblr"></i></a>
			</div>
			<div class="contact-info">
				<ul>
					<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>1500567</li>
					<li><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span><a href="mailto:kontak@kemkes.go.id">kontakkami.go.id</a></li>
				</ul>
			</div>
			<!-- Large modal -->
			
			<div class="clearfix"></div>
		</div>
	</div>
	<nav class="navbar nav_bottom" role="navigation">
	 <div class="container">
	 <!-- Brand and toggle get grouped for better mobile display -->
	   <div class="navbar-header nav_2">
		  <button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">Menu
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		  </button>
		  <a class="navbar-brand" href="#"></a>
	   </div> 
	   <!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
			<ul class="nav navbar-nav nav_1">
				<li class="current_page"><a href="#">beranda</a></li>
				
				<li><a href="contact.php">kontak</a></li>
				<li><a href="blog.php">diskusi</a></li>
			</ul>
		 </div><!-- /.navbar-collapse -->
	   </div>
	</nav>
	<!-- //header -->
	<div class="demo-2">	
		<header class="logo">
			<h1><a class="cd-logo link link--takiri" href="index. php>">pusdatin <span>is better than cure.</span></a></h1>
		</header>
            <div id="slider" class="sl-slider-wrapper">

				<div class="sl-slider">
				
					<div class="sl-slide" data-orientation="horizontal" data-slice1-rotation="-25" data-slice2-rotation="-25" data-slice1-scale="2" data-slice2-scale="2">
						<div class="sl-slide-inner">
							<div class="bg-img bg-img-1"></div>
							<h3>Cigarette Tax Pollution for Health BPJS.</h3>
							<blockquote><p>Those who receive (benefits) are also regions, for health services in the area. No, it's not a service at the center, ".</p><cite>joko widodo</cite></blockquote>
						</div>
					</div>
					
					<div class="sl-slide" data-orientation="vertical" data-slice1-rotation="10" data-slice2-rotation="-15" data-slice1-scale="1.5" data-slice2-scale="1.5">
						<div class="sl-slide-inner">
							<div class="bg-img bg-img-2"></div>
							<h3>Regula aurea.</h3>
							<blockquote><p>Until he extends the circle of his compassion to all living things, man will not himself find peace.</p><cite>Albert Schweitzer</cite></blockquote>
						</div>
					</div>
					
					<div class="sl-slide" data-orientation="horizontal" data-slice1-rotation="3" data-slice2-rotation="3" data-slice1-scale="2" data-slice2-scale="1">
						<div class="sl-slide-inner">
							<div class="bg-img bg-img-3"></div>
							<h3>Dum spiro, spero.</h3>
							<blockquote><p>Thousands of people who say they 'love' animals sit down once or twice a day to enjoy the suffering and the terror of the abattoirs.</p><cite>Dame Jane Morris Goodall</cite></blockquote>
						</div>
					</div>
					
					<div class="sl-slide" data-orientation="vertical" data-slice1-rotation="-5" data-slice2-rotation="25" data-slice1-scale="2" data-slice2-scale="1">
						<div class="sl-slide-inner">
							<div class="bg-img bg-img-4"></div>
							<h3>Donna nobis pacem.</h3>
							<blockquote><p>The human body has no more need for cows' milk than it does for dogs' milk, horses' milk, or giraffes' milk.</p><cite>Michael Klaper M.D.</cite></blockquote>
						</div>
					</div>
					
					<div class="sl-slide" data-orientation="horizontal" data-slice1-rotation="-5" data-slice2-rotation="10" data-slice1-scale="2" data-slice2-scale="1">
						<div class="sl-slide-inner">
							<div class="bg-img bg-img-5"></div>
							<h3>Acta Non Verba.</h3>
							<blockquote><p>I think if you want to eat more meat you should kill it yourself and eat it raw so that you are not blinded by the hypocrisy of having it processed for you.</p><cite>Margi Clarke</cite></blockquote>
						</div>
					</div>
				</div><!-- /sl-slider -->

				<nav id="nav-dots" class="nav-dots">
					<span class="nav-dot-current"></span>
					<span></span>
					<span></span>
					<span></span>
					<span></span>
				</nav>

			</div><!-- /slider-wrapper -->

        </div>
		<script type="text/javascript" src="js/jquery.ba-cond.min.js"></script>
		<script type="text/javascript" src="js/jquery.slitslider.js"></script>
		<script type="text/javascript">	
			$(function() {
			
				var Page = (function() {

					var $nav = $( '#nav-dots > span' ),
						slitslider = $( '#slider' ).slitslider( {
							onBeforeChange : function( slide, pos ) {

								$nav.removeClass( 'nav-dot-current' );
								$nav.eq( pos ).addClass( 'nav-dot-current' );

							}
						} ),

						init = function() {

							initEvents();
							
						},
						initEvents = function() {

							$nav.each( function( i ) {
							
								$( this ).on( 'click', function( event ) {
									
									var $dot = $( this );
									
									if( !slitslider.isActive() ) {

										$nav.removeClass( 'nav-dot-current' );
										$dot.addClass( 'nav-dot-current' );
									
									}
									
									slitslider.jump( i + 1 );
									return false;
								
								} );
								
							} );

						};

						return { init : init };

				})();

				Page.init();

				/**
				 * Notes: 
				 * 
				 * example how to add items:
				 */

				/*
				
				var $items  = $('<div class="sl-slide sl-slide-color-2" data-orientation="horizontal" data-slice1-rotation="-5" data-slice2-rotation="10" data-slice1-scale="2" data-slice2-scale="1"><div class="sl-slide-inner bg-1"><div class="sl-deco" data-icon="t"></div><h2>some text</h2><blockquote><p>bla bla</p><cite>Margi Clarke</cite></blockquote></div></div>');
				
				// call the plugin's add method
				ss.add($items);

				*/
			
			});
		</script>
		
		<!-- banner-bottom -->
		<div class="banner-bottom">
			<div class="container">
				<center>
					<h1><b>
						OUR SPEAKER
					</b></h1>
				</center>
					
				<?php  

			    while($user_data = mysqli_fetch_array($result3)) { 
			   	$idmateri = $user_data['id_materi'];
				echo"<div class='col-md-4 timing'>";
					echo "<div class='opening-hours'>";
						echo "<h3>Opening Hours</h3>";
						echo"<ul>";
							echo"<b>Tema Materi</b>";

							echo"<li>".$user_data['materi']."</li>";
							
						echo"</ul>";

						echo"<ul>";
							echo"<b>Waktu</b>";

							echo"<li>".$user_data['start_time']."-".$user_data['end_time']."</li>";
							
						echo"</ul>";
						echo"<ul>";
							echo"<b>Tanggal</b>";

							echo"<li>".$user_data['date']."</li>";
							echo"</ul>";
						
						

							echo"<div class='clearfix'></div>";
						echo"</ul>";
						echo"<ul>";
							echo"<b>Tempat</b>";

							echo"<li>".$user_data['tempat']."</li>";
						

						echo"</ul>";
					
						echo "<div>";
							echo"<center>";
								echo"<h3>Rundown</h3>";
								echo"<table style='width:100%'>";
								  echo"<tr>";
								    echo"<th>Waktu Mulai</th>";
								    echo"<th>Waktu Akhir</th>";
								    echo"<th>Keterangan</th>";
								  echo"</tr>";
								  $result4= mysqli_query($mysqli,"SELECT a.materi,a.date, a.file,a.start_time, a.end_time, a.tempat , b.eventname, b.tempat, c.speakername, c.instansi, d.waktu_mulai, d.waktu_akhir, d.keterangan FROM materis a INNER JOIN speakers c on c.id = a.speaker_id INNER JOIN events b on b.id = a.event_id INNER JOIN rundown d on d.id_materi = a.id WHERE d.id_materi = '$idmateri' ");
								  while($user_data = mysqli_fetch_array($result4)) {
								   echo"<tr>";
								    echo"<td>".$user_data['waktu_mulai']."</td>";
								    echo"<td>".$user_data['waktu_akhir']."</td>";
								    echo"<td>".$user_data['keterangan']."</td>";
								 
								  echo"</tr>";
								}
								echo"</table>";
							echo"</center>";
						echo "</div>";
						
					echo"</div>";
					echo "<div class='help'>";
						
						echo"<p>Silahkan Download Materi</p>";
						echo"<a href='".$user_data['file']."' target='_blank' class='btn btn-default btn-default_2 pull-left'>Download Materi</a>";
						echo"<hr>";
	  						echo"<a href='#' title='like' class='btn btn-counter multiple-count' data-count='0'><span>&#x2764;</span> like</a>";
	  						echo"<a href='#' title='dislike' class='btn btn-counter multiple-count' data-count='0'><span>&#x2764;</span>  dislike </a>";
					echo"</div>";
				echo"</div>";
				 
				
				echo"<div class='col-md-4 abt-img'>";
					echo"<img src='images/abt1.png' alt='doctor' title='doctor' />";
				echo"</div>";
				       
			        echo "<div class='col-md-4 abt-dec'>";
			        echo "<h2>".$user_data['speakername']."</h2>";
			        echo "<p>".$user_data['instansi']."</p>";
			        echo"</div>";        
			   
				
				echo"<div class='clearfix'>";
				echo "</div>";
			
			 }
			    ?>
			</div>
		</div>		
		<!-- //banner-bottom -->
		
		<!-- Stats -->
		<div class="stats">
			
			<h1 style="color: white">GSHA5TH, BALI</h1><br>
								<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3942.811439217665!2d115.22912151451096!3d-8.803778492454214!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd2432925a9c27b%3A0x9bad2b675ec0252b!2sBallroom+Grand+Hyatt+Bali!5e0!3m2!1sen!2sid!4v1540864405314" width="1080" height="480" frameborder="0" style="border:0" allowfullscreen></iframe>

		</div>
		<!-- //Stats -->
		<script type="text/javascript" src="js/numscroller-1.0.js"></script>
		
		<!-- tabs -->	
		<!--<div class="vertical-tabs">
			<div class="container">
				<h3 class="title text-center">session</h3>
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-8 col-xs-9 bhoechie-tab-container">
						<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 bhoechie-tab-menu">
						  <div class="list-group">
						  	<?php  

			    while($user_data1 = mysqli_fetch_array($result2)) { 
							echo "<a href='#' class='list-group-item active text-center'>";
							    echo "<p>".$user_data1['day']."</p>";
							echo"</a>";

			 }
			    ?>
							
						  </div>
						</div>
						<div class="col-lg-9 col-md-9 col-sm-9 col-xs-9 bhoechie-tab">
							<!-- flight section -->
							<!--<div class="bhoechie-tab-content active">
								<div class="services">
									<div class="ser-img">
										<img src="images/ser1.jpg" title="service" alt="" />
									</div>
									<div class="ser-info">
										
										
									</div>
									<div class="clearfix"></div>
								</div>
							</div>
							<!-- train section -->
							<!--<div class="bhoechie-tab-content">
								<div class="services">
									<div class="ser-img">
										<img src="images/ser2.jpg" title="service" alt="" />
									</div>
									<div class="ser-info">
										
										
									</div>
									<div class="clearfix"></div>
								</div>

								<div class="bhoechie-tab-content">
								<div class="services">
									<div class="ser-img">
										<img src="images/ser2.jpg" title="service" alt="" />
									</div>
									<div class="ser-info">
										
										
									</div>
									<div class="clearfix"></div>
								</div>

							</div>
				
							
							<div class="bhoechie-tab-content">
								<div class="services">
									<div class="ser-img">
										<img src="images/ser4.jpg" title="service" alt="" />
									</div>
									<div class="ser-info">
											<div class="bhoechie-tab-content">

								<div class="services">

									<div class="ser-img">
										<img src="images/ser4.jpg" title="service" alt="" />
									</div>
									<div class="ser-info">
										
										<div class="clearfix"></div>
								</div>
							</div>
							<div class="bhoechie-tab-content">
								<div class="services">
									<div class="ser-img">
										<img src="images/ser5.jpg" title="service" alt="" />
									</div>
									<div class="ser-info">
										
										<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 
											1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their 
											by English versions from the 1914 translation by H. Rackham.
										</p>
										<p>Sed ut perspiciatis unde omnis iste natus error sit, totam rem aperiam, eaque
										    ipsa quae ab illo inventore dicta sunt explicabo
										</p>
									</div>
									<div class="clearfix"></div>
								</div>
							</div>
							<div class="bhoechie-tab-content">
								<div class="services">
									<div class="ser-img">
										<img src="images/ser5.jpg" title="service" alt="" />
									</div>
									<div class="ser-info">
										<h3>registration --> 
										
			

			<div id="visual">
				<div class="slide-visual slideanim">
					<!-- Slide Image Area (1000 x 424) -->
					<ul class="slide-group">
						<li><img src="images/news1.jpg" alt="Dummy Image" class="img-responsive"/></li>
						<li><img src="images/news2.jpg" alt="Dummy Image" class="img-responsive"/></li>
						<li><img src="images/news3.jpg" alt="Dummy Image" class="img-responsive"/></li>
						<li><img src="images/news4.jpg" alt="Dummy Image" class="img-responsive"/></li>
						<li><img src="images/news5.jpg" alt="Dummy Image" class="img-responsive"/></li>
					</ul>
					<!-- Slide Description Image Area (316 x 328) -->
					<div class="script-wrap">
						<ul class="script-group">
							<li><div class="inner-script"><img src="images/news1-1.jpg" alt="Dummy Image" class="img-responsive"/></div></li>
							<li><div class="inner-script"><img src="images/news2-2.jpg" alt="Dummy Image" class="img-responsive"/></div></li>
							<li><div class="inner-script"><img src="images/news3-3.jpg" alt="Dummy Image" class="img-responsive"/></div></li>
							<li><div class="inner-script"><img src="images/news4-4.jpg" alt="Dummy Image" class="img-responsive"/></div></li>
							<li><div class="inner-script"><img src="images/news5-5.jpg" alt="Dummy Image" class="img-responsive"/></div></li>
						</ul>
						<div class="slide-controller">
							<a href="#" class="btn-prev"><img src="images/btn_prev.png" alt="Prev Slide" /></a>
							<a href="#" class="btn-play"><img src="images/btn_play.png" alt="Start Slide" /></a>
							<a href="#" class="btn-pause"><img src="images/btn_pause.png" alt="Pause Slide" /></a>
							<a href="#" class="btn-next"><img src="images/btn_next.png" alt="Next Slide" /></a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- /news -->
		
		<!-- quick links -->
		<div class="news-section" id="news">
			<div class="container">
				<div class="news-section-head text-center">
					<h3>Latest news</h3>
					<p>Here, there and everywhere... what we've been doing</p>
				</div>
				<div class="news-section-grids">
					<div class="col-md-4 news-section-grid">
						<img src="images/n1.jpg" alt="" />
						<div class="info">
							<a class="news-title" href="single.php">TINGKAT KEBERHASILAN PENYEMBUHAN TUBERKULOSIS PARU
																PRIMER PADA ANAK USIA 1-6 TAHUN DI DESA CIBUNTU
														CIBITUNG BEKASI DENGAN PENDEKATAN</a>
							<label>March 17</label>
							<p>Tuberkulosis primer disebut juga penyakit tuberkulosis pada bayi dan
										anak serta merupakan penyakit sistemik, juga penyakit menular yang
										disebabkan oleh basil Mycobacterium tuberculosa tipe humanus ( jarang oleh
										tipe Mycobacterium bovines ). Mycobacterium tuberculosa masuk melalui
										saluran nafas (droplet infection) sampai alveoli terjadilah infeksi primer. ..</span></p>
							<a class="more" href="single.php">Read more</a>
						</div>
					</div>
					<div class="col-md-4 news-section-grid">
						<img src="images/n2.jpg" alt="" />
						<div class="info">
							<a class="news-title" href="single2.php">HUBUNGAN PEMBERIAN IMUNISASI BCG DENGAN KEJADIAN
TUBERKULOSIS PARU PADA ANAK BALITA DI BALAI

PENGOBATAN PENYAKIT PARU-PARU
AMBARAWA TAHUN 2007</a>
							<label>August 28</label>
							<p>Penyakit Tuberkulosis (TB) paru sampai saat ini masih menjadi masalah
kesehatan masyarakat. Perhitungan Organisasi Kesehatan Dunia (WHO)
menunjukkan sepertiga penduduk dunia telah terinfeksi kuman TB dengan
sekitar 9 juta kasus baru Tuberkulosis setiap tahun. Artinya ada satu orang yang
terinfeksi kuman Mycobacterium Tuberkulosis setiap detik..</p>
							<a class="more" href="single2.php">Read more</a>
						</div>
					</div>
					<div class="col-md-4 news-section-grid">
						<img src="images/n3.jpg" alt="" />
						<div class="info">
						    <a class="news-title" href="single3.php">ANALISIS TINGKAT KESEHATAN PERUSAHAAN DARI ASPEK KEUANGAN

BERDASARKAN SURAT KEPUTUSAN MENTERI BUMN NOMOR: KEP-
100/MBU/2002</a>
							<label>September 12</label>
							<p>Penilaian tingkat kesehatan dari aspek keuangan menggunakan delapan indikator yaitu ROE, ROI, cash
ratio, current ratio, collection periods, perputaran persediaan, TATO dan Total Modal Sendiri terhadap Total
Aset. Hasil penilaian tingkat kesehatan keuangan PT Adhi Karya (Persero) Tbk memperoleh predikat sehat
dengan perolehan kategori A selama tahun 2012-2014. PT Adhi Karya (Persero) Tbk. diharapkan mampu
meningkatkan tingkat kesehatan keuangannya agar dapat memperoleh predikat sehat dengan kategori AAA
dengan meningkatkan kinerja keuangannya.</p>
							<a class="more" href="single3.php">Read more</a>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>

		<!-- //quick links -->
		
		<!-- book an appointment -->
		<div class="appointment">
			<div class="container">
				<div class="col-md-9 appointment-left">
					<h3>FREE APPOINTMENT BOOKING</h3>
					<p>Lorem Ipsum is simply dummy printing and typesetting industry. when an unknown printer took a galley of type and scrambled.</p>
				</div>
				<div class="col-md-3 appointment-right">
					<a href="#" class="btn btn-default btn-default_2 pull-left" data-toggle="modal" data-target="#applyModal_1">book your appointment</a>
					<div class="modal fade" id="applyModal_1" tabindex="-1" role="dialog" aria-labelledby="applyModalLabel" aria-hidden="true">
				  	<div class="modal-dialog dialog_3">
				    	<div class="modal-content">
					      	<div class="modal-header">
					        	<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
					        	<h4 class="modal-title" id="myModalLabel"><div class="head_4">
			                         <h3>Make An appointment Now</h3>
									 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro similique ipsa deleniti doloribus fuga dicta id voluptate, excepturi nostrum cupiditate</p>
			                        </div></h4>
					      	</div>
							<div class="modal-body">
								<form name="row" method="post" class="register">
                                    <input type="text" name="name" id="name" placeholder="Name" required="">
                                    <input type="text" name="email id" id="Email id" placeholder="Email id" required="">
                                    <input type="text" name="mobile number" id="Mobile Number" placeholder="Mobile Number" required="">
									<input class="date" id="datepicker" type="text" value="Appointment date" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Appointment date';}" required=>
									<textarea type="text" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter Message...';}" required="">Enter Message...</textarea>
									<input type="submit" onclick="myFunction()" value="Submit Now">
								</form>
							</div>
							<!---start-date-piker---->
								<link rel="stylesheet" href="css/jquery-ui.css" />
								<script src="js/jquery-ui.js"></script>
									<script>
										$(function() {
										$( "#datepicker" ).datepicker();
										});
									</script>
							<!---/End-date-piker---->
                     </div>
		         </div>
		     </div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<!-- //book an appointment -->
		
		<!-- news letter -->
		<div class="subscribe text-center">
			<div class="container">
				<h3>Subscribe to Our Newsletter</h3>

				<p>.</p>
				<form>
					<input placeholder="Email Address" class="user" type="text" required="">
					<input type="submit" value="Subscribe">
				</form>
				<p class="spam">We never share your information or use it to spam you</p>
			</div>
		</div>
		<!-- //news letter -->
		
		<!-- footer -->
		<footer>
			<div class="footer-grids">
				<div class="container">
					<div class="col-md-3 footer one">
						<h3>About Minister of Health</h3>
						<p> All sectors need to be involved, program harmonization so that the same vision and mission and the government has made TB as one of the National priorities in the Strategic Plan and make TB as an indicator of PISPK and Minimum Service Standards, .</p>
						<p class="adam">- Nila Moeloek, Minister of Health</p>
						<div class="clear"></div>
					</div>

					<div class="col-md-3 footer one tweet">
						<h3>Tweets</h3>
						<ul>
							<li>
								<a href="#">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accus.
								<i>http//example.com</i></a>
								<span>About 15 minutes ago<span>
							</span></span></li>
							<li>
								<a href="#"> Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit. 
								<i>http//example.com</i></a>
								<span>About a day ago<span>
							</span></span></li>
						</ul>
					</div>
					<div class="col-md-3 footer two">
						<h3>Keep Connected</h3>
						<ul>
							<li><a class="fb" href="#"><i class="fa fa-facebook"></i>Like us on Facebook</a></li>
							<li><a class="fb1" href="#"><i class="fa fa-twitter"></i>Follow us on Twitter</a></li>
							<li><a class="fb2" href="#"><i class="fa fa-google-plus"></i>Add us on Google Plus</a></li>
							<li><a class="fb3" href="#"><i class="fa fa-dribbble"></i>Follow us on Dribbble</a></li>
							<li><a class="fb4" href="#"><i class="fa fa-pinterest-p"></i>Follow us on Pinterest</a></li>
						</ul>
					</div>
					<div class="col-md-3 footer three">
						<h3>Contact Information</h3>
						<ul>
							<li><i class="fa fa-map-marker"></i><p>kementrian kesehatan <span>pusat data informasi,</span>kuningan jakarta selatan </p><div class="clearfix"></div> </li>
							<li><i class="fa fa-phone"></i><p>1234567890</p> <div class="clearfix"></div> </li>
							<li><i class="fa fa-envelope-o"></i><a href="mailto:kontak@kemkes.go.id">contact@example.com</a> <div class="clearfix"></div></li>
						</ul>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
			<!-- maps -->
			<div id="map">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.240036165201!2d106.83020511476916!3d-6.232054995488794!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f3ef2bd30e41%3A0xc13dc0af53e1a30e!2skemenkes+RI!5e0!3m2!1sen!2sid!4v1540346709667" frameborder="0" style="border:0"></iframe>
			</div>
			<div class="copy-right-grids">
				<div class="container">
					<div class="copy-left">
							<p class="footer-gd">© 2018 Prevention. All Rights Reserved | Design by <a href="http://kemkes.go.id//" target="_blank">ilham</a></p>
					</div>
					<!-- js --
					<div class="footer-links">
						<ul>
							<li><a href="sitemap.php">Sitemap</a></li>
							<li><a href="privacy_policy.php">Privacy Policy</a></li>
							<li><a href="terms.php">Terms of Use</a></li>
						</ul>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
			
		</footer>
		<!-- //footer -->

  

    <script  src="js/index.js"></script>
		<script type="text/javascript">
						$(document).ready(function() {
							/*
							var defaults = {
					  			containerID: 'toTop', // fading element id
								containerHoverID: 'toTopHover', // fading element hover id
								scrollSpeed: 1200,
								easingType: 'linear' 
					 		};
							*/
							
							$().UItoTop({ easingType: 'easeOutQuart' });
							
						});
					</script>
				<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
</body>
</html>