<?php 
$conn= new mysqli('localhost','root','','db_jadwal');
if ($conn->connect_error) {
	die("Connection Failed: " .$conn->connect_error);
}
?>