<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>admin-pusdatin</title>


    <link type="text/css" href="assets/css/vendor-bootstrap-datatables.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-timepicker.min.css">
    <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
    <!-- Bootstrap time Picker -->
    <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.min.css">
    <!-- bootstrap datepicker -->
    <link rel="stylesheet" href="bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">

    <!-- Prevent the demo from appearing in search engines -->
    <meta name="robots" content="noindex">

    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">
    <link type="text/css" href="assets/css/app.rtl.css" rel="stylesheet">

    <!-- Simplebar -->
    <link type="text/css" href="assets/vendor/simplebar.css" rel="stylesheet">
    <link type="text/css" href="assets/css/vendor-bootstrap-datepicker.css" rel="stylesheet">

</head>

<body>
    <div class="mdk-drawer-layout js-mdk-drawer-layout" data-fullbleed data-push data-responsive-width="992px" data-has-scrolling-region>

        <div class="mdk-drawer-layout__content">
            <!-- header-layout -->
            <div class="mdk-header-layout js-mdk-header-layout  mdk-header--fixed  mdk-header-layout__content--scrollable">
                <!-- header -->
                <div class="mdk-header js-mdk-header bg-primary" data-fixed>
                    <div class="mdk-header__content">

                        <nav class="navbar navbar-expand-md navbar-dark bg-primary d-flex-none">
                            <button class="btn btn-link text-white pl-0" type="button" data-toggle="sidebar">
    <i class="material-icons align-middle md-36">short_text</i>
  </button>
                            <div class="page-title m-0">data table</div>

                            <div class="collapse navbar-collapse" id="mainNavbar">
                                <ul class="navbar-nav ml-auto align-items-center">
                                    <li class="nav-item nav-link">
                                        <div class="form-group m-0">
                                            <div class="input-group input-group--inline">
                                                
                                    </li>
                                    
                                        <div class="dropdown-menu dropdown-menu-right ">
                                            <ul class="list-unstyled">
                                                <li>
                                                </li>
                                            </ul>
                                        </div>
                                    </li>
                                    <li class="nav-item dropdown notifications d-flex align-self-center align-items-center" id="navbarNotifications">
                                        
                                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="notificationsDropdown" id="notificationsDropdown">
                                            <ul class="nav nav-tabs-notifications d-flex px-0" id="notifications-ul" role="tablist">
                                                <li class="nav-item">
                                                    <a class="nav-link active" id="notifications-tab" data-toggle="tab" href="#notifications" role="tab" aria-controls="notifications" aria-selected="true">Notifications</a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link" id="alerts-tab" data-toggle="tab" href="#alerts" role="tab" aria-controls="alerts" aria-selected="false">Alerts</a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link" id="messages-tab" data-toggle="tab" href="#messages" role="tab" aria-controls="messages" aria-selected="false">Messages</a>
                                                </li>
                                            </ul>
                                            <div class="tab-content" id="notifications-tabs">
                                                <div class="tab-pane fade show active" id="notifications" role="tabpanel" aria-labelledby="notifications-tab">
                                                    <ul class="list-group list-group-flush">
                                                        <li class="list-group-item">
                                                            <div class="w-100">
                                                                <a href="#">john</a> received a new quote</div>
                                                            <div class="w-100 text-muted">4 secs ago</div>
                                                        </li>
                                                        <li class="list-group-item">
                                                            <div class="w-100">
                                                                <a href="#">karen</a> received a new quote</div>
                                                            <div class="w-100 text-muted">25 mins ago</div>
                                                        </li>
                                                        <li class="list-group-item">
                                                            <div class="w-100">
                                                                <a href="#">jim</a> received a new quote</div>
                                                            <div class="w-100 text-muted">7 hrs ago</div>
                                                        </li>
                                                        <li class="list-group-item text-right">
                                                            <a href="#">
                    <span class="align-middle">View All</span>
                    <i class="material-icons md-18 align-middle">arrow_forward</i>
                  </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div class="tab-pane fade" id="alerts" role="tabpanel" aria-labelledby="alerts-tab">
                                                    <ul class="list-group list-group-flush">
                                                        <li class="list-group-item">
                                                            <div class="media align-items-center">
                                                                <i class="material-icons align-middle mr-2 text-warning">
                      info_outline
                    </i>
                                                                <div class="media-body">
                                                                    <div class="w-100">
                                                                        <a href="profile.html">john</a> received a new
                                                                        <a href="#">quote</a>
                                                                    </div>
                                                                    <div class="w-100 text-muted">4 secs ago</div>
                                                                </div>
                                                            </div>
                                                        </li>
                                                        <li class="list-group-item">
                                                            <div class="media align-items-center">
                                                                <i class="material-icons align-middle mr-2 text-success">
                      check_circle
                    </i>
                                                                <div class="media-body">
                                                                    <div class="w-100">
                                                                        <a href="profile.html">karen</a> completed a
                                                                        <a href="#">task</a>
                                                                    </div>
                                                                    <div class="w-100 text-muted">25 mins ago</div>
                                                                </div>
                                                            </div>
                                                        </li>
                                                        <li class="list-group-item">
                                                            <div class="media align-items-center">
                                                                <i class="material-icons align-middle mr-2 text-danger">
                      warning
                    </i>
                                                                <div class="media-body">
                                                                    <div class="w-100">
                                                                        <a href="profile.html">jim</a> removed a
                                                                        <a href="#">task</a>
                                                                    </div>
                                                                    <div class="w-100 text-muted">7 hrs ago</div>
                                                                </div>
                                                            </div>
                                                        </li>
                                                        <li class="list-group-item text-right">
                                                            <a href="#">
                    <span class="align-middle">View All</span>
                    <i class="material-icons md-18 align-middle">arrow_forward</i>
                  </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div class="tab-pane fade" id="messages" role="tabpanel" aria-labelledby="messages-tab">
                                                    <ul class="list-group list-group-flush">
                                                        <li class="list-group-item">
                                                            <div class="media align-items-center">
                                                                <a href="profile.html">
                      <img src="assets/images/avatars/person-1.jpg" class="img-fluid rounded-circle mr-2" width="35" alt="">
                    </a>
                                                                <div class="media-body">
                                                                    <div class="w-100">I started that project we talked...</div>
                                                                    <div class="w-100 text-muted">4 secs ago</div>
                                                                </div>
                                                            </div>
                                                        </li>
                                                        <li class="list-group-item">
                                                            <div class="media align-items-center">
                                                                <a href="profile.html">
                      <img src="assets/images/avatars/person-11.jpg" class="img-fluid rounded-circle mr-2" width="35" alt="">
                    </a>
                                                                <div class="media-body">
                                                                    <div class="w-100">Can we arrange a meeting?...</div>
                                                                    <div class="w-100 text-muted">25 mins ago</div>
                                                                </div>
                                                            </div>
                                                        </li>
                                                        <li class="list-group-item">
                                                            <div class="media align-items-center">
                                                                <a href="profile.html">
                      <img src="assets/images/avatars/person-12.jpg" class="img-fluid rounded-circle mr-2" width="35" alt="">
                    </a>
                                                                <div class="media-body">
                                                                    <div class="w-100">We need to fix some bugs...</div>
                                                                    <div class="w-100 text-muted">7 hrs ago</div>
                                                                </div>
                                                            </div>
                                                        </li>
                                                        <li class="list-group-item text-right">
                                                            <a href="#">
                    <span class="align-middle">View All</span>
                    <i class="material-icons md-18 align-middle">arrow_forward</i>
                  </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="nav-item nav-divider">
                                        <li class="nav-item">
                                            <a href="#" class="nav-link dropdown-toggle dropdown-clear-caret" data-toggle="sidebar" data-target="#user-drawer">
         
        </a>
                                        </li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
       
    
                <!-- content -->
                <div class="mdk-header-layout__content top-navbar mdk-header-layout__content--scrollable h-100">
                    <!-- main content -->
                    <div class="container-fluid">
                        <h2>Tables</h2>
                       
                        <h2>Data tables</h2>
                        <p class="lead">
                            Customized data table.
                        </p>
                        <hr>
                         <div class="col-lg-12">
                                        <div class="card card-account">
                                            <div class="card-body">
                                                <?php 
                                                include('../function/dbconn.php');
                                                if (isset($_POST['submit'])){
$materi=$_POST['firstname'];
$tempat=$_POST['tempat'];
$start_time=$_POST['starttime'];
$end_time=$_POST['endtime'];
$schedule=$_POST['schedule'];
$speaker_id=$_POST['speaker'];
$conn->query("INSERT INTO `materis`(`materi`, `start_time`, `end_time`, `date`, `tempat`,`speaker_id`) VALUES ('$materi','$start_time','$end_time','$schedule','$tempat','$speaker_id')")or die(mysql_error());


echo "<script>alert('succesfull saved!!'); window.location='Dashboard.php'</script>";
}
                                                    ?>
                                                <form action="dashboard.php" method="post">
                                                    <div class="form-row">
                                                        <div class="form-group col-lg-6">
                                                            <label>Materi</label>
                                                            <div class="input-group input-group--inline">
                                                                <div class="input-group-addon">
                                                                    <i class="material-icons">book</i>
                                                                </div>
                                                                <input type="text" class="form-control" name="firstname" placeholder="input materi">
                                                            </div>
                                                        </div>
                                                        </div>
                                                        <div class="form-group col-lg-6">
                                                            <label>tempat</label>
                                                            <div class="input-group input-group--inline">
                                                                <div class="input-group-addon">
                                                                    <i class="material-icons">home</i>
                                                                </div>
                                                                <input type="text" class="form-control" name="tempat" placeholder="input tempat">
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-lg-6">
                                                            <label>speaker</label>
                                                            <div class="input-group input-group--inline">
                                                                <div class="input-group-addon">
                                                                    <i class="material-icons">peopleview</i>
                                                                </div>
                                                                <input type="text" class="form-control" name="speaker" placeholder="input speaker">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-row">
                                                        <div class="form-group col-lg-6">
                                                            <label>Lokasi</label>
                                                            <div class="input-group input-group--inline">
                                                                <div class="input-group-addon">
                                                                    <i class="material-icons">streetview</i>
                                                                </div>
                                                                <input type="text" class="form-control" name="lokasi" placeholder="Input Lokasi">
                                                            </div>
                                                        
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>start time</label>
                                                        <div class="input-group input-group--inline">
                                                            <div class="input-group-addon">
                                                                <i class="material-icons">schedule</i>
                                                            </div>
                                                           <div class="bootstrap-timepicker">
            <input type="text" class="form-control timepicker" id="time_in" name="starttime" required>
        </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>end time</label>
                                                        <div class="input-group input-group--inline">
                                                            <div class="input-group-addon">
                                                                <i class="material-icons">schedule</i>
                                                            </div>
                                                            <div class="bootstrap-timepicker">
            <input type="text" class="form-control timepicker" id="time_in" name="endtime" required>
        </div>
                                                        </div>
                                                         <div class="card-body">
                            </div>
                        </div>
                       <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Input schedule</h4>
                            </div>
                            <div class="card-body">
                                <input type="text" name="schedule" class="datepicker form-control" value="10-10-2018">

                            </div>
                        </div>

                                                    
                                                    <button type = "submit" name ="submit" class="btn btn-success">Save changes</button>
                                                </form>
                                                <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">
                                    Data table
                                </h4>
                            </div>
                                                        <div class="py-4">
                                <div class="table-responsive">
                                    <table id="data-table" class="table table-striped table-bordered" style="width:75%">
                                        <thead>
                                            <tr>
                                                <th>materi</th>
                                                <th>lokasi</th>
                                                <th>starttime</th>
                                                <th>endtime</th>
                                                <th>schedule</th>
                                                <th>speaker</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php include('../function/dbconn.php');


                                            $query=$conn->query("SELECT * FROM materis order by materi ASC ");
                                            while($fetch = $query->fetch_array()){
                                            ?>
                                            <tr>
                                                <td><?php echo $fetch['materi']; ?></td>                                                
                                                <td><?php echo $fetch['tempat']; ?></td>
                                                <td><?php echo $fetch['start_time']; ?></td>
                                                <td><?php echo $fetch['end_time']; ?></td>
                                                <td><?php echo $fetch['date']; ?></td>
                                                <td><?php echo $fetch['speaker_id']; ?></td>
                                            </tr>

                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                                            </div>
                                        </div>
                                    </div>
                        
                    </div>
                </div>
            </div>

        </div>
        
        <!-- // END drawer-layout__content -->

        <!-- drawer -->
        <div class="mdk-drawer js-mdk-drawer" id="default-drawer">
            <div class="mdk-drawer__content">
                <div class="mdk-drawer__inner" data-simplebar data-simplebar-force-enabled="true">

                    <nav class="drawer  drawer--dark">
                        <div class="drawer-spacer">
                            <div class="media align-items-center">
                                <a href="index.html" class="drawer-brand-circle mr-2">I</a>
                                <div class="media-body">
                                    <a href="index.html" class="h5 m-0 text-link">Admin</a>
                                </div>
                            </div>
                        </div>
                        <!-- HEADING -->
                        <div class="py-2 drawer-heading">
                            Dashboards
                        </div>
                        <!-- MENU -->
                       <!-- <ul class="drawer-menu" id="dasboardMenu" data-children=".drawer-submenu">
                            <li class="drawer-menu-item ">
                                <a href="index.html">
                        <!-- MENU -->
                        <!--<ul class="drawer-menu" id="mainMenu" data-children=".drawer-submenu">
                            <li class="drawer-menu-item drawer-submenu">
                                <a data-toggle="collapse" data-parent="#mainMenu" href="#" data-target="#uiComponentsMenu" aria-controls="uiComponentsMenu" aria-expanded="false" class="collapsed">
                                        <ul class="collapse " id="uiComponentsMenu">
                                    <li class="drawer-menu-item "><a href="ui-buttons.html">Buttons</a></li>
                                    <li class="drawer-menu-item "><a href="ui-colors.html">Colors</a></li>
                                    <li class="drawer-menu-item "><a href="ui-grid.html">Grid</a></li>
                                    <li class="drawer-menu-item "><a href="ui-icons.html">Icons</a></li>
                                    <li class="drawer-menu-item "><a href="ui-typography.html">Typography</a></li>
                                    <li class="drawer-menu-item "><a href="ui-drag-drop.html">Drag &amp; Drop</a></li>
                                    <li class="drawer-menu-item "><a href="ui-loaders.html">Loaders</a></li>
                                </ul>
                            </li>


                            <li class="drawer-menu-item drawer-submenu">
                                <a data-toggle="collapse" data-parent="#mainMenu" href="#" data-target="#formsMenu" aria-controls="formsMenu" aria-expanded="false" class="collapsed">
        <i class="material-icons">text_format</i>
        <span class="drawer-menu-text"> Forms</span>
      </a>
                                <ul class="collapse " id="formsMenu">
                                    <li class="drawer-menu-item "><a href="form-controls.html">Form Controls</a></li>
                                    <li class="drawer-menu-item "><a href="checkboxes-radios.html">Checkboxes &amp; Radios</a></li>
                                    <li class="drawer-menu-item "><a href="switches-toggles.html">Switches &amp; Toggles</a></li>
                                    <li class="drawer-menu-item "><a href="form-layout.html">Layout Variations</a></li>
                                    <li class="drawer-menu-item "><a href="validation.html">Validation</a></li>
                                    <li class="drawer-menu-item "><a href="custom-forms.html">Custom Forms</a></li>
                                    <li class="drawer-menu-item "><a href="text-editor.html">Text Editor</a></li>
                                    <li class="drawer-menu-item "><a href="datepicker.html">Datepicker</a></li>
                                </ul>
                            </li>
                            <li class="drawer-menu-item  active ">
                                <a href="ui-tables.html">
        <i class="material-icons">tab</i>
        <span class="drawer-menu-text"> Tables</span>
      </a>
                            </li>
                            <li class="drawer-menu-item  ">
                                <a href="ui-notifications.html">
        <i class="material-icons">notifications</i>
        <span class="drawer-menu-text"> Notifications</span>
      </a>
                            </li>
                            <li class="drawer-menu-item  ">
                                <a href="charts.html">
        <i class="material-icons">equalizer</i>
        <span class="drawer-menu-text"> Charts</span>
      </a>
                            </li>
                            <li class="drawer-menu-item  ">
                                <a href="events-calendar.html">
        <i class="material-icons">event_available</i>
        <span class="drawer-menu-text"> Calendar</span>
      </a>
                            </li>
                            <li class="drawer-menu-item  ">
                                <a href="maps.html">
        <i class="material-icons">pin_drop</i>
        <span class="drawer-menu-text"> Maps</span>
      </a>
                            </li>
                        </ul>


                        <!-- HEADING -->
                        <!--<div class="py-2 drawer-heading">
                            Pages
                        </div>

                        <!-- MENU -->
                        <ul class="drawer-menu" id="mainMenu" data-children=".drawer-submenu">
                            <li class="drawer-menu-item">
                                <a href="Dashboard.php">
        <i class="material-icons">edit</i>
        <span class="drawer-menu-text">Edit data</span>
      </a>


                            
        <!-- // END drawer -->

        <!-- drawer -->
        <div class="mdk-drawer js-mdk-drawer" id="user-drawer" data-position="right" data-align="end">
            <div class="mdk-drawer__content">
                <div class="mdk-drawer__inner" data-simplebar data-simplebar-force-enabled="true">
                    <nav class="drawer drawer--light">
                        <div class="drawer-spacer drawer-spacer-border">
                            <div class="media align-items-center">
                                <img src="../../../pbs.twimg.com/profile_images/928893978266697728/3enwe0fO_400x400.jpg" class="img-fluid rounded-circle mr-2" width="35" alt="">
                                
                            </div>
                        </div>
                        <div class="drawer-spacer bg-body-bg">
                            <div class="d-flex justify-content-between mb-2">
                                <p class="h6 text-gray m-0"><i class="material-icons align-middle md-18 text-primary">monetization_on</i> Balance</p>
                                <span>$21,011</span>
                            </div>
                            <div class="d-flex justify-content-between">
                                <p class="h6 text-gray m-0"><i class="material-icons align-middle md-18 text-primary">shopping_cart</i> Sales</p>
                                <span>142</span>
                            </div>
                        </div>
                        <!-- MENU -->
                        <ul class="drawer-menu" id="userMenu" data-children=".drawer-submenu">
                            <li class="drawer-menu-item">
                                <a href="account.html">
        <i class="material-icons">lock</i>
        <span class="drawer-menu-text"> Account</span>
      </a>
                            </li>
                            <li class="drawer-menu-item">
                                <a href="profile.html">
        <i class="material-icons">account_circle</i>
        <span class="drawer-menu-text"> Profile</span>
      </a>
                            </li>
                            <li class="drawer-menu-item">
                                <a href="login.html">
        <i class="material-icons">exit_to_app</i>
        <span class="drawer-menu-text"> Logout</span>
      </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <!-- // END drawer -->

    </div>
    <!-- // END drawer-layout -->



    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>
<script src="assets/vendor/bootstrap-datepicker.min.js"></script>
    <script src="assets/js/datepicker.js"></script>
    <!-- Bootstrap -->
    <script src="assets/vendor/popper.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Simplebar -->
    <!-- Used for adding a custom scrollbar to the drawer -->
    <script src="assets/vendor/simplebar.js"></script>


    <!-- Vendor -->
    <script src="assets/vendor/Chart.min.js"></script>
    <script src="assets/vendor/moment.min.js"></script>

    <!-- APP -->
    <script src="assets/js/color_variables.js"></script>
    <script src="assets/js/app.js"></script>


    <script src="assets/vendor/dom-factory.js"></script>
    <!-- DOM Factory -->
    <script src="assets/vendor/material-design-kit.js"></script>
    <!-- MDK -->

<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- datepicker -->
<script src="bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<!-- bootstrap time picker -->
<script src="plugins/timepicker/bootstrap-timepicker.min.js"></script>

<script>
$(function(){
    //Date picker
  $('#datepicker_add').datepicker({
    autoclose: true,
    format: 'yyyy-mm-dd'
  })
  $('#datepicker_edit').datepicker({
    autoclose: true,
    format: 'yyyy-mm-dd'
  })

  //Timepicker
  $('.timepicker').timepicker({
    showInputs: false
  })

  //Date range picker
  $('#reservation').daterangepicker()
  //Date range picker with time picker
  $('#reservationtime').daterangepicker({ timePicker: true, timePickerIncrement: 30, format: 'MM/DD/YYYY h:mm A' })
  //Date range as a button
  $('#daterange-btn').daterangepicker(
    {
      ranges   : {
        'Today'       : [moment(), moment()],
        'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
        'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
        'This Month'  : [moment().startOf('month'), moment().endOf('month')],
        'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
      },
      startDate: moment().subtract(29, 'days'),
      endDate  : moment()
    },
    function (start, end) {
      $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
    }
  )
  
});
</script>

    <script>
        (function() {
            'use strict';
            // Self Initialize DOM Factory Components
            domFactory.handler.autoInit()


            // Connect button(s) to drawer(s)
            var sidebarToggle = document.querySelectorAll('[data-toggle="sidebar"]')

            sidebarToggle.forEach(function(toggle) {
                toggle.addEventListener('click', function(e) {
                    var selector = e.currentTarget.getAttribute('data-target') || '#default-drawer'
                    var drawer = document.querySelector(selector)
                    if (drawer) {
                        if (selector == '#default-drawer') {
                            $('.container-fluid').toggleClass('container--max');
                        }
                        drawer.mdkDrawer.toggle();
                    }
                })
            })
        })()
    </script>


    <script src="assets/vendor/jquery.dataTables.js"></script>
    <script src="assets/vendor/dataTables.bootstrap4.js"></script>

    <script>
        $('#data-table').dataTable();
    </script>


</body>

</html>