<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>kemenkes| by : pusdatin</title>
<?php include_once "config.php";?>
<link href="css/pignose.layerslider.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/pignose.layerslider.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/gallery.css" rel="stylesheet" type="text/css" media="all" /> <!-- gallery css -->
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Prevention Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<!--fonts-->
<link href='//fonts.googleapis.com/css?family=Poiret+One' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//fonts-->	
<!-- js -->
<script type="text/javascript" src="js/jquery.min.js"></script>
<!-- js -->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/bootstrap.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<link rel="stylesheet" href="css/font-awesome.min.css" />
        <link rel="stylesheet" type="text/css" href="css/custom.css" />
		<script type="text/javascript" src="js/modernizr.custom.79639.js"></script>		
		<!-- js for news -->
		<script src="js/jquery.easing.min.js"></script>
		<script type="text/javascript" src="js/pignose.layerslider.js"></script>
		<script type="text/javascript">
			//<![CDATA[
				$(window).load(function() {
					$('#visual').pignoseLayerSlider({
						play    : '.btn-play',
						pause   : '.btn-pause',
						next    : '.btn-next',
						prev    : '.btn-prev'
					});
				});
	pon		//]]>
			</script>
		<!-- /js for news -->
		
		<!-- for smooth scrolling -->
		<script type="text/javascript" src="js/move-top.js"></script>
		<script type="text/javascript" src="js/easing.js"></script>
		<script type="text/javascript">
		jQuery(document).ready(function($) {
			$(".scroll").click(function(event){		
				event.preventDefault();
				$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
			});
		});
		</script>
		<!-- //for smooth scrolling -->
</head>
<body>
	<!-- header -->
	<div class="top-strip">
		<div class="container-fluid">
			<div class="social-icons">
				<a class="facebook" href="#"><i class="fa fa-facebook"></i></a>
				<a class="twitter" href="#"><i class="fa fa-twitter"></i></a>
				<a class="pinterest" href="#"><i class="fa fa-pinterest-p"></i></a>
				<a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a>
				<a class="tumblr" href="#"><i class="fa fa-tumblr"></i></a>
			</div>
			<div class="contact-info">
				<ul>
					<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>+0123 384 920</li>
					<li><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span><a href="mailto:kontak@kemkes.go.id">kontakkami.co.id</a></li>
				</ul>
			</div>
			<!-- Large modal -->
			<!--
			<div class="selectpackage">
				<button class="btn btn-primary" data-toggle="modal" data-target="#myModal">Packages</button>
					<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
						<div class="modal-dialog modal-lg">
							<div class="modal-content">
								<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
										&times;</button>
									<h4 class="modal-title package-title" id="myModalLabel">
										PREVENTIVE HEALTH CHECK UP PACKAGES</h4>
								</div>
								<div class="modal-body packages">
									<div class="col-md-4 text-center modal-align">
										<div class="package">
											<p>A set of basic tests that can give a broad overview of your health status.</p>
											<i class="fa fa-heartbeat"></i>
											<h4>MASTER HEALTH CHECK</h4>
											<a href="book-a-test.html">Book Now</a>
										</div>
									</div>
									<div class="col-md-4 text-center modal-align">
										<div class="package">
											<p>Are you looking for a comprehensive health check that includes even Eye, Dental and ENT checks?</p>
											<i class="fa fa-medkit"></i>
											<h4>WHOLE BODY CHECKUP</h4>
											<a href="book-a-test.html">Book Now</a>
										</div>
									</div>
									<div class="col-md-4 text-center modal-align">
										<div class="package">
											<p>Do you wish to check your body out for an entire spectrum of diseases in a luxurious ambience?</p>
											<i class="fa fa-user-md"></i>
											<h4>HEALTH CHECK 1 AND 2</h4>
											<a href="book-a-test.html">Book Now</a>
										</div>
									</div>
									<div class="clearfix"></div>
								</div>
							</div>
						</div>
					</div>
				<script>
				$('#myModal').modal('');
				</script>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<nav class="navbar nav_bottom" role="navigation">
	 <div class="container">
	 <!-- Brand and toggle get grouped for better mobile display -->
	 <div class="clearfix"></div>
		</div>
	</div>
	<nav class="navbar nav_bottom" role="navigation">
	 <div class="container">
	   <div class="navbar-header nav_2">
		  <button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">Menu
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		  </button>
		  <a class="navbar-brand" href="#"></a>
	   </div> 
	   <!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
			<ul class="nav navbar-nav nav_1">
				<li class="current_page"><a href="#">diskusi</a></li>
				
				<li><a href="contact.php">kontak</a></li>
				<li><a href="blog.php">beranda</a></li>
				<li class="dropdown">
				</ul>
				</div><!-- /.navbar-collapse -->
	   </div>
	</nav>		<!--
				<li class="dropdown">
				  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Lab<span class="caret"></span></a>
				  <ul class="dropdown-menu drop_menu" role="menu">
					<li><a href="laboratory.html">About Lab</a></li>
					<li><a href="quality.html">Quality</a></li>
					<li><a href="technologies.html">Technologies</a></li>
					<li><a href="instruments.html">Instruments</a></li>
				  </ul>
				</li>
				<li class="dropdown">
				  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Book Test<span class="caret"></span></a>
				  <ul class="dropdown-menu drop_menu" role="menu">
					<li><a href="book-a-test.html">Book a Test</a></li>
					<li><a href="test-list.html">Test Menu</a></li>
				  </ul>
				</li>
				<li class="dropdown">
				  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Opportunity<span class="caret"></span></a>
				  <ul class="dropdown-menu drop_menu" role="menu">
					<li><a href="career.html">Careers</a></li>
					<li><a href="404.html">Franchisee</a></li>
				  </ul>
				</li>
				<li class="dropdown">
				  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Pages<span class="caret"></span></a>
				  <ul class="dropdown-menu drop_menu" role="menu">
					<li><a href="news.html">News</a></li>
					<li><a href="faq.html">Faq</a></li>
					<li><a href="mobile-app.html">App</a></li>
					<li><a href="login.html">Login</a></li>
					<li><a href="terms.html">Terms of Use</a></li>
					<li><a href="shortcodes.html">Shortcodes</a></li>
					<li><a href="privacy_policy.html">Privacy Policy</a></li>
				  </ul>
				</li>
				<li class="current_page"><a href="blog.html">Blog</a></li>
				<li><a href="contact.html">Contact</a></li>
			</ul>
		 </div><!-- /.navbar-collapse -->
	   </div>
	</nav>
	<!-- //header -->
		<!-- blog-section -->
		<section class="blog-single-post">
			<div class="inner-banner demo-2 text-center">
				<header class="logo">
					<h1><a class="cd-logo link link--takiri" href="index.php">Prevention <span>is better than cure.</span></a></h1>
				</header>
				<div id="breadcrumb_wrapper">
					<div class="container">		
						<h2>Blog-post</h2>
						<h6>add a short description here</h6>
					</div>
				</div>
			</div>
			<!--- blog ---->
			<div class="blog">
				<div class="container">
					<div class="single">		
				<div class="single-top">
					<img  src="images/single-post-img.jpg" alt=""/>
				</div>
				<div class="top-single">
				<h3>TINGKAT KEBERHASILAN PENYEMBUHAN TUBERKULOSIS PARU
																PRIMER PADA ANAK USIA 1-6 TAHUN DI DESA CIBUNTU
														CIBITUNG BEKASI DENGAN PENDEKATAN.</h3>
					<div class="grid-single">
						<div class="single-one"><span><i class="fa fa-calendar"></i>6/10/2018 </div></li>
						<div class="single-one"><span><a href="#"><i class="fa fa-comment"></i>200</a></span></div>
						<div class="single-one"><span><i class="fa fa-heart"></i>400</span></div>
						<div class="clearfix"> </div>
					</div>
					<p class="eget"><b>Berdasarkan umur responden,</b> Jumlah responden berdasarkan umur di Klinik Ngudi Saras Trikilan Kali
							Jambe Sragen sebanyak 3 orang berumur 20-25 tahun , 3 orang berumur 26-
							30 tahun, dan sebanyak 6 orang yang berumur 30-35 tahun. Berdasarkan
							pekerjaan yang paling banyak bekerja sebagai ibu rumah tangga 7 responden
							(58,33%). Berdasarkan riwayat persalinan responden yang menjalani
							persalinan paling banyak yaitu persalinan multigravida sebanyak 7
							responden (58,33%), sedangkan yang menjalani persalinan primigravida
							sebanyak 5 responden (42,33%). Berdasarkan riwayat persalinan, semua
							responden belum pernah ada yang melakukan persalinan dan ada juga yang
							sudah pernah melakukan persalinan.</p> 
			<p class="eget"> banyak pasien yang akan menjalani
							persalinan pada umur 20 – 25 tahun. Pasien yang berada pada umur tersebut
							banyak yang mengalami tingkat kecemasan berat yaitu sebanyak 3
							responden (25 %), kecemasan dapat terjadi pada semua usia, tapi lebih
							banyak terjadi pada usia lebih dewasa. Sedangkan pada umur 26 – 30 lebih
							banyak mengalami tingkat kecemasan berat yaitu sebanyak 5 responden
							(42, 33%). <b>.dan pada umur 26 – 30 hanya 1 responden (8,33%) yang
							mengalami kecemasan sedang. Sedangkan pada umur yang lebih tua umur
							31 – 35 tahun pada penelitian ini lebih mengalami kecemasan sedang
							sebanyak 2 reponden (16, 67%) (tabel 2). Pendapat Soewardi (1998) bahwa
							individu yang matur adalah individu yang memiliki kematangan kepribadian. </p>

			<p class="eget"> CurabituSebagian besar responden yang bekerja sebagai ibu rumah tangga
							merupakan responden yang paling banyak mengalami tingkat kecemasan
							berat sebanyak 5 responden (42,33%)r <b>faktor pekerjaan merupakan salah satu
							faktor yang berpengaruh terhadap kecemasan, dimana seorang memiliki
							pekerjaan beresiko justru memiliki koping yang lebih baik karena terbiasa
							menghadapi keadaan atau situasi-situasi yang rumit (tabel 3). Pendapat ini
							sesuai dengan penelitian ini bahwa pasien yang mengalami tingkat
							kecemasan yang paling banyak bekerja sebagai ibu rumah tangga.  <b> Dimana
							mempunyai stressor yang paling berat dibanding pekerjaan lain.</b> </p>
						
					<ul class="share">
						<li>share :</li>
						<li>							
							<div id="fb-root"></div>
							<script>(function(d, s, id) {
							  var js, fjs = d.getElementsByTagName(s)[0];
							  if (d.getElementById(id)) return;
							  js = d.createElement(s); js.id = id;
							  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.0";
							  fjs.parentNode.insertBefore(js, fjs);
							}(document, 'script', 'facebook-jssdk'));</script>
	   						
	   						<div class="fb-like" data-href="https://www.facebook.com/w3layouts" data-layout="button_count" data-action="like" data-show-faces="true" data-share="false"></div></li>
						<li><a href="https://twitter.com/w3layouts" class="twitter-share-button" data-dnt="true">Tweet</a>
						<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script></li>
					</ul>
					<div class="leave">
						<h3>Leave a comment</h3>
							<form method="post"> 
								<div class="single-grid">
									<div class="col-md-6 single-us">
										<input type="text" placeholder="Name" name="nama" onfocus="this.value='';" onblur="if (this.value == '') {this.value = 'nama';}" required="">
									</div>
									<!-- <div class="col-md-6 single-us">
										<input type="text" placeholder="E-mail" onfocus="this.value='';" onblur="if (this.value == '') {this.value = 'E-mail';}" required="">
									</div> -->
									<div class="clearfix"> </div>
								</div>
								<!-- <div class="single-grid">
									<div class="col-md-6 single-us">
										<input type="text" placeholder="Web site" onfocus="this.value='';" onblur="if (this.value == '') {this.value = 'Web site';}" required="">
									</div>
									<div class="col-md-6 single-us">
										<input type="text" placeholder="Job" onfocus="this.value='';" onblur="if (this.value == '') {this.value = 'Job';}" required="">
									</div>
									<div class="clearfix"> </div>
								</div> -->
								<div class="text-top">
									<div class="col-md-8 text-in">
										<textarea  placeholder="Comment" name="post_content" onfocus="this.value='';" onblur="if (this.value == '') {this.value = 'post_content';}" required="">Comment</textarea>
									</div>
									<div class="col-md-4 text-in">
										<input type="submit" name="post" value="SEND">
									</div>
									<div class="clearfix"> </div>
								</div>
							</form>
							<?php	
								
								$query = mysqli_query($mysqli,"SELECT *,UNIX_TIMESTAMP() - date_posted AS TimeSpent from post order by post_id DESC");
								while($post_row = mysqli_fetch_array($query)){
								$id = $post_row['post_id'];	
								$nama = $post_row['nama'];	
								$posted_by = $post_row['nama'];
							?>
							<p></p>		
					</div>

					<div class="top-comments">
						<div class="met">
							<div class="code-in">
								<p class="smith"><a href="#"><?php echo $posted_by; ?> </a> 
									<span>
										<?php				
											$days = floor($post_row['TimeSpent'] / (60 * 60 * 24));
											$remainder = $post_row['TimeSpent'] % (60 * 60 * 24);
											$hours = floor($remainder / (60 * 60));
											$remainder = $remainder % (60 * 60);
											$minutes = floor($remainder / 60);
											$seconds = $remainder % 60;
											if($days > 0)
											echo date('F d, Y - H:i:sa', $post_row['date_posted']);
											elseif($days == 0 && $hours == 0 && $minutes == 0)
											echo "A few seconds ago";		
											elseif($days == 0 && $hours == 0)
											echo $minutes.' minutes ago';
										?>							
									</span>
								</p>
								<!-- <p class="reply"><a href="#"><i class="fa fa-reply"></i>REPLY</a></p> -->
								<div class="clearfix"> </div>
							</div>
							<div class="comments-top-top">
								<div class="men" >
									<img   src="images/men.png" alt=""> 
								</div>					
									<p class="men-it"><?php echo $post_row['content']; ?></p>
								<div class="clearfix"> </div>
							</div>
						</div>

						<!-- <div class="met met-in">
							<div class="code-in">
								<p class="smith"><a href="#">abdul</a> <span>06 november 2018, 15:37</span></p>
								<div class="clearfix"> </div>
							</div>
							<div class="comments-top-top top-in">
								<div class="men" >
									<img   src="images/men.png" alt=""> 
								</div>					
									<p class="men-it"> bagaimana Karakteristik Responden berdasarkan Umur, Pekerjaan, dan Riwayat
											Persalinan?</p>
								<div class="clearfix"> </div>
							</div>
						</div> -->
						</div>

					<!-- <a style="text-decoration:none; float:right;" href="deletepost.php<?php echo '?id='.$id; ?>"><button><font color="red">x</button></font></a>
					<h3>Posted by: <a href="#"> <?php echo $posted_by; ?></a>
					-
						<?php				
								$days = floor($post_row['TimeSpent'] / (60 * 60 * 24));
								$remainder = $post_row['TimeSpent'] % (60 * 60 * 24);
								$hours = floor($remainder / (60 * 60));
								$remainder = $remainder % (60 * 60);
								$minutes = floor($remainder / 60);
								$seconds = $remainder % 60;
								if($days > 0)
								echo date('F d, Y - H:i:sa', $post_row['date_posted']);
								elseif($days == 0 && $hours == 0 && $minutes == 0)
								echo "A few seconds ago";		
								elseif($days == 0 && $hours == 0)
								echo $minutes.' minutes ago';
						?>
					<br>
					<br><?php echo $post_row['content']; ?></h3> -->
					</br>
				
							<?php 
								$comment_query = mysqli_query($mysqli,"SELECT * ,UNIX_TIMESTAMP() - date_posted AS TimeSpent FROM comment where post_id = '$id'") or die (mysqli_error());
								while ($comment_row=mysqli_fetch_array($comment_query)){
								$comment_id = $comment_row['comment_id'];
								$comment_by = $comment_row['nama'];
							?>

					<br>
					<div class="top-comments">
					<div class="met met-in">
							<div class="code-in">
								<p class="smith"><a href="#"><?php echo $comment_by; ?></a> <span><?php				
								$days = floor($comment_row['TimeSpent'] / (60 * 60 * 24));
								$remainder = $comment_row['TimeSpent'] % (60 * 60 * 24);
								$hours = floor($remainder / (60 * 60));
								$remainder = $remainder % (60 * 60);
								$minutes = floor($remainder / 60);
								$seconds = $remainder % 60;
								if($days > 0)
								echo date('F d, Y - H:i:sa', $comment_row['date_posted']);
								elseif($days == 0 && $hours == 0 && $minutes == 0)
								echo "A few seconds ago";		
								elseif($days == 0 && $hours == 0)
								echo $minutes.' minutes ago';
							?></span></p>
								<div class="clearfix"> </div>
							</div>
							<div class="comments-top-top top-in">
								<div class="men" >
									<img   src="images/men.png" alt=""> 
								</div>					
									<p class="men-it"> <?php echo $comment_row['content']; ?></p>
								<div class="clearfix"> </div>
							</div>
					</div>
					</div>
						<!-- <a href="#"><?php echo $comment_by; ?></a> - <?php echo $comment_row['content']; ?>
					<br>
							<?php				
								$days = floor($comment_row['TimeSpent'] / (60 * 60 * 24));
								$remainder = $comment_row['TimeSpent'] % (60 * 60 * 24);
								$hours = floor($remainder / (60 * 60));
								$remainder = $remainder % (60 * 60);
								$minutes = floor($remainder / 60);
								$seconds = $remainder % 60;
								if($days > 0)
								echo date('F d, Y - H:i:sa', $comment_row['date_posted']);
								elseif($days == 0 && $hours == 0 && $minutes == 0)
								echo "A few seconds ago";		
								elseif($days == 0 && $hours == 0)
								echo $minutes.' minutes ago';
							?>
					<br> -->
							<?php
							}
							?>
					<hr>
					<div class="leave">
					<form method="post">
					<hr>
					Reply:<br>
					<input type="hidden" name="id" value="<?php echo $id; ?>">
					<div class="single-grid">
									<div class="col-md-6 single-us">
										<input type="text" placeholder="Name" name="nama" onfocus="this.value='';" onblur="if (this.value == '') {this.value = 'nama';}" required="">
									</div>
									<div class="clearfix"> </div>
								</div>
								<div class="text-top">
									<div class="col-md-8 text-in">
										<textarea  placeholder="Comment" name="comment_content" onfocus="this.value='';" onblur="if (this.value == '') {this.value = 'post_content';}" required="">Comment</textarea>
									</div>
									<div class="col-md-4 text-in">
										<input type="submit" name="comment" value="SEND">
									</div>
									<div class="clearfix"> </div>
								</div>
					</form>
					</div>	
					
					&nbsp;
					<?php 
					if ($u_id = $id){
					?>
					
				
					
					<?php }else{ ?>
						
					<?php
					} } ?>
					
				
							<?php
								if (isset($_POST['post'])){
								$post_content  = $_POST['post_content'];
								$nama = $_POST['nama'];
								// mysqli_query($mysqli,"insert into post (nama,content,date_created) values ('$nama','$post_content','".strtotime(date("Y-m-d h:i:sa"))."') ")or die(mysqli_error());
								$mysqli->query("INSERT INTO `post`(`nama`,`content`, `date_posted` )  VALUES ('$nama','$post_content','".strtotime(date("Y-m-d h:i:sa"))."')")or die(mysql_error());
								header('location:single.php');
								}
							?>

							<?php
							
								if (isset($_POST['comment'])){
								$comment_content = $_POST['comment_content'];
								$post_id=$_POST['id'];
								$nama = $_POST['nama'];
								// mysqli_query($mysqli,"insert into comment (post_id,nama,content,date_posted) values ('$post_id','$nama','$comment_content','".strtotime(date("Y-m-d h:i:sa"))."')") or die (mysqli_error());
								$mysqli->query("INSERT INTO `comment`(`post_id`,`nama`, `content`, `date_posted` )  VALUES ('$post_id','$nama','$comment_content','".strtotime(date("Y-m-d h:i:sa"))."')")or die(mysql_error());
								header('location:single.php');
								}
							?>

					
					</div>
					</div>
				</div>
			</div>
			<!--- /blog ---->
		</section>
		<!-- //blog-section -->
		<!-- book an appointment -->

		</div>
		<!-- //book an appointment -->
		
		<!-- news letter -->
		
		</div>
		<!-- //news letter -->
		
		<!-- footer -->
		<footer>
			<div class="footer-grids">
				<div class="container">
					<div class="col-md-3 footer one">
						<h3>About Company</h3>
						<p> All sectors need to be involved, program harmonization so that the same vision and mission and the government has made TB as one of the National priorities in the Strategic Plan and make TB as an indicator of PISPK and Minimum Service Standards.</p>
						<p class="adam">-  Nila Moeloek, Minister of Health</p>
						<div class="clear"></div>
					</div>
					<div class="col-md-3 footer one tweet">
						<h3>Tweets</h3>
						<ul>
							<li>
								<a href="#">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accus.
								<i>http//example.com</i></a>
								<span>About 15 minutes ago<span>
							</span></span></li>
							<li>
								<a href="#"> Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit. 
								<i>http//example.com</i></a>
								<span>About a day ago<span>
							</span></span></li>
						</ul>
					</div>
					<div class="col-md-3 footer two">
						<h3>Keep Connected</h3>
						<ul>
							<li><a class="fb" href="#"><i class="fa fa-facebook"></i>Like us on Facebook</a></li>
							<li><a class="fb1" href="#"><i class="fa fa-twitter"></i>Follow us on Twitter</a></li>
							<li><a class="fb2" href="#"><i class="fa fa-google-plus"></i>Add us on Google Plus</a></li>
							<li><a class="fb3" href="#"><i class="fa fa-dribbble"></i>Follow us on Dribbble</a></li>
							<li><a class="fb4" href="#"><i class="fa fa-pinterest-p"></i>Follow us on Pinterest</a></li>
						</ul>
					</div>
					<div class="col-md-3 footer three">
						<h3>Contact Information</h3>
						<ul>
							<li><i class="fa fa-map-marker"></i><p>kementrian kesehatan republik indonesia <span>pusat data informasi,</span>kuningan jakarta </p><div class="clearfix"></div> </li>
							<li><i class="fa fa-phone"></i><p>1234567890</p> <div class="clearfix"></div> </li>
							<li><i class="fa fa-envelope-o"></i><a href="mailto:kontak@kemkes.go.id">contact@example.com</a> <div class="clearfix"></div></li>
						</ul>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
			<!-- maps -->
			<div id="map">
				
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.240036165201!2d106.83020511476916!3d-6.232054995488794!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f3ef2bd30e41%3A0xc13dc0af53e1a30e!2skemenkes+RI!5e0!3m2!1sen!2sid!4v1540346709667" frameborder="0" style="border:0"></iframe>
			</div>
			<div class="copy-right-grids">
				<div class="container">
					<div class="copy-left">
							<p class="footer-gd">© 2018 Prevention. All Rights Reserved | Design by <a href="http://kemkes.go.id/" target="_blank">ilham</a></p>
					</div>
					<!-- js --
					<div class="footer-links">
						<ul>
							<li><a href="sitemap.html">Sitemap</a></li>
							<li><a href="privacy_policy.html">Privacy Policy</a></li>
							<li><a href="terms.html">Terms of Use</a></li>
						</ul>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</footer>
		<!-- //footer -->
		<script type="text/javascript">
						$(document).ready(function() {
							/*
							var defaults = {
					  			containerID: 'toTop', // fading element id
								containerHoverID: 'toTopHover', // fading element hover id
								scrollSpeed: 1200,
								easingType: 'linear' 
					 		};
							*/
							
							$().UItoTop({ easingType: 'easeOutQuart' });
							
						});
					</script>
				<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
</body>
</html>