<?php 
include('function/dbconn.php');
if (isset($_POST['submit'])){
$username=$_POST['name'];
$password=$_POST['password'];
$email=$_POST['email'];

$login_query=$conn->query("SELECT * FROM ussers WHERE name='$username' and password='$password' and email='$email' ");
$count=$login_query->num_rows;

if($count > 0){
echo "<script>alert('succesfull login!!'); window.location='index.php'</script>";
}else{
	echo"<script>alert('invalid username, email and password! tri again.');
	window.location='login.php</script>";
?>
<?php }
}
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>kementrian kesehatan republik indonesia :: pusdatin</title>
	<!-- Meta tags -->
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Student Matriculate Form Responsive Widget, Audio and Video players, Login Form Web Template, Flat Pricing Tables, Flat Drop-Downs, Sign-Up Web Templates, Flat Web Templates, Login Sign-up Responsive Web Template, Smartphone Compatible Web Template, Free Web Designs for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design"
	/>
	<script type="application/x-javascript">
		addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); }
	</script>
	<!-- Meta tags -->
	<link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all" />
	<!-- //pop-ups-->
	<!-- Calendar -->
<link rel="stylesheet" href="css/jquery-ui.css" />
<!-- //Calendar -->

	<!-- font-awesome icons -->
	<link rel="stylesheet" href="css/font-awesome.min.css" />
	<!-- //font-awesome icons -->
	<!--stylesheets-->
	<link href="css/stylelogin.css" rel='stylesheet' type='text/css' media="all">
	<!--//style sheet end here-->
	<link href="//fonts.googleapis.com/css?family=Cuprum:400,700" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
</head>

<body>
	<h1 class="header-w3ls">
		kementrian kesehatan republik indonesia</h1>
	<div class="icon-stu">
	
		<h2 class="student-w3l">Login And Register Form</h2>
		<div class="stude-user-wls">
			<span class="fa fa-user" aria-hidden="true"></span>
			<div class="clear"> </div>
		</div>
		<div class="row-col">
			<div class="banner-agileits-btm">
				<div class="w3layouts_more-buttn">
					<a href="#small-dialog1 " class="play-icon popup-with-zoom-anim">login</a>
				</div>
				<div id="small-dialog1" class="mfp-hide w3ls_small_dialog wthree_pop">
					<div class="agileits_modal_body">

						<!--login form-->
						<div class="newsletter ">
							<h2>Login Form</h2>

							<div class="letter-w3ls">
								<form method="post">

									<div class="form-left-w3l">

										<input type="text" class="top-up" name="name" placeholder="Name" required="">
									</div>

									<div class="form-left-w3l">
										<input type="email" name="email" required="" placeholder="Email">
									</div>
									<div class="form-right-w3ls ">

										<input type="password" name="password" placeholder="Password" required="">

									</div>
									<div class="btnn">
										<button type="submit" name="submit">LOGIN</button><br>
									</div>
								</form>


								<div class="clear"></div>
							</div>
							<!--//login form-->

						</div>
					</div>
                  </div>
				</div>
				<div class="banner-its-btm">

					<div class="outs_more-buttn">
						<a href="#small-dialog2 " class="play-icon popup-with-zoom-anim">Register</a>
					</div>
					<div id="small-dialog2" class="mfp-hide w3ls_small_dialog wthree_pop">
						<div class="agileits_modal_body">
<?php 
include('function/dbconn.php');
if (isset($_POST['signup'])){
$username=$_POST['name'];
$id_ussers=$_POST['id_ussers'];
$password=$_POST['password'];
$email=$_POST['email'];
$phonenumber=$_POST['phonenumber'];
$gender=$_POST['gender'];
$dateofbirth=$_POST['dateofbirth'];
$streetaddress=$_POST['streetaddress'];
$city=$_POST['city'];
$password=$_POST['password'];
$selectcountry=$_POST['country'];
$conn->query("INSERT INTO `ussers`(`id_ussers`, `name`, `email`, `phone_number`, `date`, `jenis_kelamin`, `street_addreess`, `city`, `password`, `select_contry`) VALUES ('$id_ussers','$username','$email','$phonenumber','$dateofbirth','$gender','$streetaddress','$city','$password','$selectcountry')")or die(mysql_error());


echo "<script>alert('succesfull signup!!'); window.location='login.php'</script>";
}
 ?>
							<!--register form-->
							<div class="student-reg-w3 ">
								<h3>Register Form</h3>
								<div class="letter-w3ls">

									<form method="post">
										<div class="main">
											<div class="form-right-to-w3ls">
									<input type="text" name="id_ussers" placeholder="id_ussers" required="">
										<div class="clear"></div>
									</div>
											<div class="form-left-to-w3l">

												<input type="text" name="name" placeholder="Name" required="">
												<div class="clear"></div>
											</div>
											
                                             
										</div>
							
								<div class="main">
									<div class="form-left-to-w3l">

										<input type="email" name="email" placeholder="Email" required="">
										  <div class="clear"></div>
									</div>
									<div class="form-right-to-w3ls">

										<input type="text" name="phonenumber" placeholder="Phone Number" required="">
										  <div class="clear"></div>
									</div>
								</div>
								<div class="main">
									<div class="form-left-to-w3l">

										<input type="text" name="gender" placeholder="gender" required="">
										<div class="clear"></div>
									</div>
									 
								</div>

								<div class="main">

								
					   <div class="form-right-to-w3ls">
     <input  id="datepicker1" name="dateofbirth" type="text" placeholder="Date of Birth" required="">
	  <div class="clearfix"></div>
	 </div>
			</div>


								<div class="form-add-to-w3ls add">

									<input type="text" name="streetaddress" placeholder="Street Address" required="">
									  <div class="clear"></div>
								</div>


								<div class="main">
									<div class="form-left-to-w3l">

										<input type="text" name="city" placeholder="City" required="">
										<div class="clear"></div>
									</div>
									<div class="form-right-to-w3ls">
										<input type="text" name="state" placeholder="State" required="">
										<div class="clear"></div>
									</div>
									 
								</div>
								<div class="main">
									<div class="form-left-to-w3l">
										<input type="text" name="password" placeholder="password" required="">
										<div class="clear"></div>
									</div>
									<div class="form-right-to-w3ls">
									<input type="text" name="country" placeholder="country" required="">
										<div class="clear"></div>
										</div>
									
																						
	                                   <div class="clear"></div>
									</div>
								
								</div>
								
								<div class="btnn">
									<button type="submit" name="signup" >Sign up</button><br>
								</div>

								</form>
							</div>
						</div>
						<!--//register form-->

					</div>
				</div>
				<div class="clear"> </div>
			</div>
			</div>
			</div>
			<div class="copy">
				<p>kemenkes- pusdatin <a href="http://kemkes.go.id//" target="_blank">kemenkes</a></p>
			</div>

			<script type='text/javascript' src='js/jquery-2.2.3.min.js'></script>

			<!--scripts-->

			<!--//scripts-->
			<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
			<script>
				$(document).ready(function () {
					$('.popup-with-zoom-anim').magnificPopup({
						type: 'inline',
						fixedContentPos: false,
						fixedBgPos: true,
						overflowY: 'auto',
						closeBtnInside: true,
						preloader: false,
						midClick: true,
						removalDelay: 300,
						mainClass: 'my-mfp-zoom-in'
					});

				});
			</script>
			<!-- //pop-up-box video -->
			<!-- //js -->
			<!-- Calendar -->
				<script src="js/jquery-ui.js"></script>
				  <script>
						  $(function() {
							$( "#datepicker,#datepicker1,#datepicker2,#datepicker3" ).datepicker();
						  });
				  </script>
			<!-- //Calendar -->

 </body>
</html>